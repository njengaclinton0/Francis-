import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';

const String DEFAULT_BACKEND_URL = "http://192.168.0.102:8000";

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: ".env").catchError((_) {});
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SmartRiskEA',
      theme: ThemeData(primarySwatch: Colors.indigo),
      home: LoginScreen(),
    );
  }
}

class LoginScreen extends StatefulWidget {
  @override
  State createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _userController = TextEditingController(text: "demo");
  final _passController = TextEditingController(text: "demo");
  bool _loading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("SmartRiskEA Login")),
      body: Padding(
        padding: EdgeInsets.all(18.0),
        child: Column(children: [
          TextField(controller: _userController, decoration: InputDecoration(labelText: "Username")),
          SizedBox(height: 8),
          TextField(controller: _passController, decoration: InputDecoration(labelText: "Password"), obscureText: true),
          SizedBox(height: 18),
          Row(children: [
            Expanded(
              child: ElevatedButton(
                onPressed: _loading ? null : () async {
                  setState(() => _loading = true);
                  await Future.delayed(Duration(milliseconds: 400)); // fake auth delay
                  setState(() => _loading = false);
                  Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => DashboardScreen()));
                },
                child: _loading ? CircularProgressIndicator(color: Colors.white) : Text("Login"),
              ),
            )
          ]),
          SizedBox(height: 18),
          Text("Backend: ${dotenv.env['BACKEND_URL'] ?? DEFAULT_BACKEND_URL}", style: TextStyle(fontSize: 12, color: Colors.grey)),
        ]),
      ),
    );
  }
}

class DashboardScreen extends StatefulWidget {
  @override
  State createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  String backend = dotenv.env['BACKEND_URL'] ?? DEFAULT_BACKEND_URL;
  Map<String,dynamic>? accountInfo;
  bool loading = false;

  @override
  void initState() {
    super.initState();
    fetchAccountInfo();
  }

  Future<void> fetchAccountInfo() async {
    setState(() { loading = true; });
    try {
      final uri = Uri.parse("$backend/account/info");
      final res = await http.get(uri).timeout(Duration(seconds: 8));
      if (res.statusCode == 200) {
        accountInfo = jsonDecode(res.body);
      } else {
        accountInfo = {'error': 'status ${res.statusCode}', 'body': res.body};
      }
    } catch (e) {
      accountInfo = {'error': e.toString()};
    }
    setState(() { loading = false; });
  }

  Future<void> openTrade(String side) async {
    final symbol = "EURUSD";
    final payload = jsonEncode({
      'symbol': symbol,
      'side': side,
      'volume': 0.01,
      'sl_pips': 30,
      'tp_pips': 60
    });
    try {
      final uri = Uri.parse("$backend/trade/open");
      final res = await http.post(uri, body: payload, headers: {'Content-Type':'application/json'}).timeout(Duration(seconds:8));
      showSnack("Open trade response: ${res.statusCode}");
      await fetchAccountInfo();
    } catch (e) {
      showSnack("Trade failed: $e");
    }
  }

  Future<void> closeAll() async {
    try {
      final uri = Uri.parse("$backend/trade/close_all");
      final res = await http.post(uri, body: jsonEncode({'magic':20251028}), headers: {'Content-Type':'application/json'}).timeout(Duration(seconds:8));
      showSnack("CloseAll response: ${res.statusCode}");
      await fetchAccountInfo();
    } catch (e) {
      showSnack("Close failed: $e");
    }
  }

  void showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("SmartRiskEA Dashboard"), actions: [
        IconButton(icon: Icon(Icons.refresh), onPressed: fetchAccountInfo),
        IconButton(icon: Icon(Icons.logout), onPressed: () { Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => LoginScreen())); }),
      ]),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text("Backend: $backend", style: TextStyle(fontWeight: FontWeight.bold)),
          SizedBox(height: 10),
          loading ? Center(child: CircularProgressIndicator()) : AccountInfoCard(info: accountInfo),
          SizedBox(height: 16),
          Text("Quick Actions", style: TextStyle(fontWeight: FontWeight.bold)),
          SizedBox(height: 8),
          Row(children: [
            Expanded(child: ElevatedButton(onPressed: () => openTrade('buy'), child: Text("Open BUY"))),
            SizedBox(width:8),
            Expanded(child: ElevatedButton(onPressed: () => openTrade('sell'), child: Text("Open SELL"))),
          ]),
          SizedBox(height: 8),
          ElevatedButton.icon(onPressed: closeAll, icon: Icon(Icons.cancel), label: Text("Close All EA Positions")),
          SizedBox(height: 16),
          Text("Note: This is a shell app. Connect your backend at ${backend}"),
        ]),
      ),
    );
  }
}

class AccountInfoCard extends StatelessWidget {
  final Map<String,dynamic>? info;
  AccountInfoCard({this.info});

  @override
  Widget build(BuildContext context) {
    if (info == null) return Text("No data. Press refresh.");
    if (info!.containsKey('error')) return Text("Error: ${info!['error']}");
    final acc = info!['info'] ?? info;
    final positions = info!['positions'] ?? [];
    return Card(
      child: Padding(padding: EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text("Account Summary:", style: TextStyle(fontWeight: FontWeight.bold)),
        SizedBox(height:6),
        Text(acc.toString().substring(0, acc.toString().length>200?200:acc.toString().length)),
        SizedBox(height:8),
        Text("Open Positions: ${positions is List ? positions.length : positions.toString()}"),
        if (positions is List && positions.isNotEmpty)
          ...positions.map<Widget>((p) => ListTile(
            dense: true,
            title: Text("${p['symbol'] ?? p['instrument'] ?? 'n/a'} ${p['side'] ?? p['type'] ?? ''}"),
            subtitle: Text("vol:${p['volume'] ?? p['size']}, pr:${p['price'] ?? ''}, p/l:${p['profit'] ?? p['grossProfit'] ?? ''}"),
          )).toList()
      ])),
    );
  }
}
