SmartRiskEA Flutter Shell - README

This folder contains the minimal Flutter source files for the SmartRiskEA mobile shell.

How to use:
1. Install Flutter SDK: https://flutter.dev/docs/get-started/install
2. Create a new Flutter project (or use this folder as the project root)
   flutter create smartrisk_mobile
3. Replace the generated lib/main.dart with the one provided here.
4. Save the provided pubspec.yaml (replace project's pubspec.yaml contents).
5. Add a file named .env at project root with:
   BACKEND_URL=http://192.168.0.102:8000
6. Run:
   flutter pub get
   flutter run     # to run on device/emulator
   flutter build apk --release  # to build an APK
Notes:
- If running on a physical Android device, ensure the device can reach the backend IP.
- For emulator, use 10.0.2.2:8000 to access host.
